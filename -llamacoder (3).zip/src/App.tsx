import { useState, useEffect, useCallback } from 'react';
import { AnimatePresence } from 'framer-motion';
import { User, Post, Notification, TabType } from './types';
import { useAuth, usePosts, useNotifications, useTheme, useBookmarks } from './utils/hooks';
import { LoginScreen } from './components/LoginScreen';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { ComposeBox } from './components/ComposeBox';
import { PostCard } from './components/PostCard';
import { ProfileView } from './components/ProfileView';
import { EditProfileModal } from './components/EditProfileModal';
import { Toast } from './components/Toast';
import { NotificationsView } from './components/NotificationsView';
import { ExploreView } from './components/ExploreView';

export default function App() {
  const { user, isLoading, login, logout, updateUser } = useAuth();
  const { posts, addPost, deletePost, toggleLike } = usePosts();
  const { notifications, unreadCount, addNotification, markAsRead, markAllAsRead } = useNotifications();
  const { isDark, toggleTheme } = useTheme();
  const { isBookmarked, toggleBookmark } = useBookmarks();

  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [toast, setToast] = useState({ message: '', visible: false });

  // Generate sample notifications for new users
  useEffect(() => {
    if (user && notifications.length === 0) {
      const sampleNotifications: Notification[] = [
        {
          id: 'notif_1',
          type: 'like',
          message: 'أعجب بمنشورك',
          fromUser: 'مبدع سعودي',
          fromAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sample_0',
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          read: false
        },
        {
          id: 'notif_2',
          type: 'follow',
          message: 'بدأ بمتابعتك',
          fromUser: 'رائد التقنية',
          fromAvatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sample_1',
          createdAt: new Date(Date.now() - 7200000).toISOString(),
          read: false
        }
      ];
      sampleNotifications.forEach(n => addNotification(n));
    }
  }, [user, notifications.length, addNotification]);

  const showToast = useCallback((message: string) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast({ message: '', visible: false }), 2500);
  }, []);

  const handlePost = useCallback((content: string, imageUrl?: string) => {
    if (user) {
      const newPost: Post = {
        id: `post_${Date.now()}`,
        content,
        author_name: user.full_name,
        author_avatar: user.avatar_url,
        username: user.username,
        likes: 0,
        likedBy: [],
        comments: 0,
        created_at: new Date().toISOString(),
        image_url: imageUrl
      };
      addPost(newPost);
      showToast('تم النشر ✨');
    }
  }, [user, addPost, showToast]);

  const handleLike = useCallback((postId: string) => {
    if (user) {
      toggleLike(postId, user.id);
    }
  }, [user, toggleLike]);

  const handleDelete = useCallback((postId: string) => {
    deletePost(postId);
    showToast('تم حذف المنشور');
  }, [deletePost, showToast]);

  const handleShare = useCallback((post: Post) => {
    navigator.clipboard.writeText(post.content);
    showToast('تم نسخ المحتوى للحافظة');
  }, [showToast]);

  const handleBookmark = useCallback((postId: string) => {
    toggleBookmark(postId);
    showToast(isBookmarked(postId) ? 'تم إزالة الحفظ' : 'تم الحفظ');
  }, [toggleBookmark, isBookmarked, showToast]);

  const handleSaveProfile = useCallback((updatedUser: User) => {
    if (updatedUser) {
      updateUser(updatedUser);
      showToast('تم تحديث إعداداتك بنجاح ✅');
    }
  }, [updateUser, showToast]);

  const handleTabChange = useCallback((tab: TabType) => {
    setCurrentTab(tab);
  }, []);

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-gray-500 font-bold">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginScreen onLogin={login} />;
  }

  return (
    <div className="h-screen flex flex-col bg-gray-100 dark:bg-gray-950 max-w-lg mx-auto relative overflow-hidden">
      <Header
        user={user}
        isDark={isDark}
        unreadNotifications={unreadCount}
        onToggleTheme={toggleTheme}
        onOpenSettings={() => setIsEditModalOpen(true)}
        onLogout={logout}
        onNotificationsClick={() => setCurrentTab('notifications')}
      />

      <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-gray-950">
        <AnimatePresence mode="wait">
          {currentTab === 'home' && (
            <div key="home">
              <ComposeBox user={user} onPost={handlePost} />
              <div className="divide-y divide-gray-100 dark:divide-gray-800 pb-32">
                {posts.length === 0 ? (
                  <div className="p-20 text-center">
                    <div className="text-6xl mb-4">📝</div>
                    <p className="text-gray-400 font-black">لا توجد منشورات</p>
                    <p className="text-gray-400 text-sm mt-2">كن أول من ينشر!</p>
                  </div>
                ) : (
                  posts.map(post => (
                    <PostCard
                      key={post.id}
                      post={post}
                      currentUserId={user.id}
                      currentUsername={user.username}
                      isBookmarked={isBookmarked(post.id)}
                      onLike={handleLike}
                      onBookmark={handleBookmark}
                      onDelete={post.username === user.username ? handleDelete : undefined}
                      onShare={handleShare}
                    />
                  ))
                )}
              </div>
            </div>
          )}

          {currentTab === 'explore' && (
            <ExploreView
              key="explore"
              posts={posts}
              currentUserId={user.id}
              currentUsername={user.username}
              isBookmarked={isBookmarked}
              onLike={handleLike}
              onBookmark={handleBookmark}
              onDelete={handleDelete}
            />
          )}

          {currentTab === 'notifications' && (
            <NotificationsView
              key="notifications"
              notifications={notifications}
              onMarkAsRead={markAsRead}
              onMarkAllAsRead={markAllAsRead}
            />
          )}

          {currentTab === 'profile' && (
            <ProfileView
              key="profile"
              user={user}
              posts={posts}
              currentUserId={user.id}
              isBookmarked={isBookmarked}
              onLike={handleLike}
              onBookmark={handleBookmark}
              onDelete={handleDelete}
              onOpenSettings={() => setIsEditModalOpen(true)}
            />
          )}
        </AnimatePresence>
      </main>

      <BottomNav
        currentTab={currentTab}
        unreadNotifications={unreadCount}
        onTabChange={handleTabChange}
      />

      <EditProfileModal
        user={user}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleSaveProfile}
      />

      <Toast message={toast.message} isVisible={toast.visible} />
    </div>
  );
}