import { useState, useEffect, useCallback } from 'react';
import { User, Post, Notification } from '../types';
import {
  loadUserFromStorage,
  saveUserToStorage,
  clearUserFromStorage,
  createDefaultUser,
  loadPostsFromStorage,
  savePostsToStorage,
  generateSamplePosts,
  loadNotificationsFromStorage,
  saveNotificationsToStorage,
  loadBookmarksFromStorage,
  saveBookmarksToStorage
} from './helpers';

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedUser = loadUserFromStorage();
    if (storedUser) {
      setUser(storedUser);
    }
    setIsLoading(false);
  }, []);

  const login = useCallback(() => {
    const newUser = createDefaultUser();
    saveUserToStorage(newUser);
    setUser(newUser);

    const existingPosts = loadPostsFromStorage();
    if (existingPosts.length === 0) {
      const samplePosts = generateSamplePosts(newUser);
      savePostsToStorage(samplePosts);
    }
  }, []);

  const logout = useCallback(() => {
    clearUserFromStorage();
    setUser(null);
  }, []);

  const updateUser = useCallback((updatedUser: User) => {
    saveUserToStorage(updatedUser);
    setUser(updatedUser);
  }, []);

  return { user, isLoading, login, logout, updateUser };
};

export const usePosts = () => {
  const [posts, setPosts] = useState<Post[]>([]);

  useEffect(() => {
    setPosts(loadPostsFromStorage());
  }, []);

  const addPost = useCallback((post: Post) => {
    setPosts(prev => {
      const newPosts = [post, ...prev];
      savePostsToStorage(newPosts);
      return newPosts;
    });
  }, []);

  const deletePost = useCallback((postId: string) => {
    setPosts(prev => {
      const newPosts = prev.filter(p => p.id !== postId);
      savePostsToStorage(newPosts);
      return newPosts;
    });
  }, []);

  const toggleLike = useCallback((postId: string, userId: string) => {
    setPosts(prev => {
      const newPosts = prev.map(post => {
        if (post.id === postId) {
          const hasLiked = post.likedBy.includes(userId);
          return {
            ...post,
            likes: hasLiked ? post.likes - 1 : post.likes + 1,
            likedBy: hasLiked
              ? post.likedBy.filter(id => id !== userId)
              : [...post.likedBy, userId]
          };
        }
        return post;
      });
      savePostsToStorage(newPosts);
      return newPosts;
    });
  }, []);

  const getUserPosts = useCallback((username: string) => {
    return posts.filter(post => post.username === username);
  }, [posts]);

  const refreshPosts = useCallback(() => {
    setPosts(loadPostsFromStorage());
  }, []);

  return { posts, addPost, deletePost, toggleLike, getUserPosts, refreshPosts };
};

export const useBookmarks = () => {
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  useEffect(() => {
    setBookmarks(loadBookmarksFromStorage());
  }, []);

  const toggleBookmark = useCallback((postId: string) => {
    setBookmarks(prev => {
      const newBookmarks = prev.includes(postId)
        ? prev.filter(id => id !== postId)
        : [...prev, postId];
      saveBookmarksToStorage(newBookmarks);
      return newBookmarks;
    });
  }, []);

  const isBookmarked = useCallback((postId: string) => {
    return bookmarks.includes(postId);
  }, [bookmarks]);

  return { bookmarks, toggleBookmark, isBookmarked };
};

export const useNotifications = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    setNotifications(loadNotificationsFromStorage());
  }, []);

  const addNotification = useCallback((notification: Notification) => {
    setNotifications(prev => {
      const newNotifications = [notification, ...prev];
      saveNotificationsToStorage(newNotifications);
      return newNotifications;
    });
  }, []);

  const markAsRead = useCallback((notificationId: string) => {
    setNotifications(prev => {
      const newNotifications = prev.map(n =>
        n.id === notificationId ? { ...n, read: true } : n
      );
      saveNotificationsToStorage(newNotifications);
      return newNotifications;
    });
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => {
      const newNotifications = prev.map(n => ({ ...n, read: true }));
      saveNotificationsToStorage(newNotifications);
      return newNotifications;
    });
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  return {
    notifications,
    unreadCount,
    addNotification,
    markAsRead,
    markAllAsRead
  };
};

export const useTheme = () => {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('tuwaiq_theme');
    if (stored === 'dark') {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = useCallback(() => {
    setIsDark(prev => {
      const newValue = !prev;
      localStorage.setItem('tuwaiq_theme', newValue ? 'dark' : 'light');
      if (newValue) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return newValue;
    });
  }, []);

  return { isDark, toggleTheme };
};