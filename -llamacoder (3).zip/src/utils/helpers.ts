import { User, Post, Notification } from '../types';

// User Helpers
export const generateUserId = (): string => {
  return 'usr_' + Math.random().toString(36).substring(7);
};

export const generateUsername = (id: string): string => {
  return 'tuwaiq_' + id.substring(4, 7);
};

export const generateDefaultAvatar = (seed: string): string => {
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}`;
};

export const createDefaultUser = (): User => {
  const id = generateUserId();
  return {
    id,
    full_name: 'بطل طويق',
    username: generateUsername(id),
    avatar_url: generateDefaultAvatar(id),
    bio: 'همة تعانق السماء، شغوف بالتكنولوجيا وبناء المستقبل 🇸🇦',
    location: 'الرياض، السعودية',
    birthday: '',
    joinDate: new Date().toISOString()
  };
};

// Storage Helpers
export const saveUserToStorage = (user: User): void => {
  localStorage.setItem('tuwaiq_user', JSON.stringify(user));
};

export const loadUserFromStorage = (): User | null => {
  const stored = localStorage.getItem('tuwaiq_user');
  return stored ? JSON.parse(stored) : null;
};

export const clearUserFromStorage = (): void => {
  localStorage.removeItem('tuwaiq_user');
};

// Posts Storage
export const savePostsToStorage = (posts: Post[]): void => {
  localStorage.setItem('tuwaiq_posts', JSON.stringify(posts));
};

export const loadPostsFromStorage = (): Post[] => {
  const stored = localStorage.getItem('tuwaiq_posts');
  const posts = stored ? JSON.parse(stored) : [];
  return posts.map((p: Post) => ({
    ...p,
    likedBy: p.likedBy || [],
    comments: p.comments || 0,
    image_url: p.image_url || undefined
  }));
};

// Notifications Storage
export const saveNotificationsToStorage = (notifications: Notification[]): void => {
  localStorage.setItem('tuwaiq_notifications', JSON.stringify(notifications));
};

export const loadNotificationsFromStorage = (): Notification[] => {
  const stored = localStorage.getItem('tuwaiq_notifications');
  return stored ? JSON.parse(stored) : [];
};

// Bookmarks Storage
export const saveBookmarksToStorage = (bookmarks: string[]): void => {
  localStorage.setItem('tuwaiq_bookmarks', JSON.stringify(bookmarks));
};

export const loadBookmarksFromStorage = (): string[] => {
  const stored = localStorage.getItem('tuwaiq_bookmarks');
  return stored ? JSON.parse(stored) : [];
};

// Date Formatting
export const formatDateArabic = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('ar-SA', { day: 'numeric', month: 'long' });
};

export const formatDateShort = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (seconds < 60) return 'الآن';
  if (minutes < 60) return `منذ ${minutes} دقيقة`;
  if (hours < 24) return `منذ ${hours} ساعة`;
  if (days < 7) return `منذ ${days} يوم`;
  return date.toLocaleDateString('ar-SA');
};

export const formatJoinDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString('ar-SA', { month: 'long', year: 'numeric' });
};

// Generate sample data for new users
export const generateSamplePosts = (user: User): Post[] => {
  const sampleContents = [
    'مرحباً بكم في منصة طويق! 🇸🇦',
    'اليوم بدأت رحلتي في عالم البرمجة، أتمنى لكم التوفيق!',
    'السعودية تتحول لمركز تقني عالمي 🚀',
    'القهوة والكود.. مزيج مثالي للإبداع ☕️💻',
    'همة تعانق السماء، وعزيمة لا تعرف المستحيل!'
  ];

  const usernames = ['saudi_coder', 'tech_pioneer', 'future_builder', 'code_master', 'innovation_seeker'];
  const names = ['مبدع سعودي', 'رائد التقنية', 'صانع المستقبل', 'خبير البرمجة', 'مبتكر'];

  return sampleContents.map((content, index) => ({
    id: `post_${Date.now()}_${index}`,
    content,
    author_name: names[index],
    author_avatar: generateDefaultAvatar(`sample_${index}`),
    username: usernames[index],
    likes: Math.floor(Math.random() * 50) + 10,
    likedBy: [],
    comments: Math.floor(Math.random() * 10),
    created_at: new Date(Date.now() - (index * 3600000)).toISOString()
  }));
};

// Image helpers
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

export const validateImageFile = (file: File): { valid: boolean; error?: string } => {
  const maxSize = 5 * 1024 * 1024; // 5MB
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'نوع الصورة غير مدعوم (JPEG, PNG, GIF, WebP فقط)' };
  }

  if (file.size > maxSize) {
    return { valid: false, error: 'حجم الصورة كبير جداً (الحد الأقصى 5MB)' };
  }

  return { valid: true };
};