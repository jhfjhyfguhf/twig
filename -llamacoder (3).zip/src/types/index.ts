export interface User {
  id: string;
  full_name: string;
  username: string;
  avatar_url: string;
  bio: string;
  location: string;
  birthday: string;
  joinDate: string;
}

export interface Post {
  id: string;
  content: string;
  author_name: string;
  author_avatar: string;
  username: string;
  likes: number;
  likedBy: string[];
  comments: number;
  created_at: string;
  image_url?: string;
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow';
  message: string;
  fromUser: string;
  fromAvatar: string;
  createdAt: string;
  read: boolean;
}

export type TabType = 'home' | 'explore' | 'notifications' | 'profile';
export type ProfileTabType = 'my-tweets' | 'my-media' | 'my-likes';