import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, TrendingUp, Hash } from 'lucide-react';
import { Post } from '../types';
import { PostCard } from './PostCard';

interface ExploreViewProps {
  posts: Post[];
  currentUserId: string;
  currentUsername: string;
  isBookmarked: (id: string) => boolean;
  onLike: (id: string) => void;
  onBookmark: (id: string) => void;
  onDelete: (id: string) => void;
}

export const ExploreView = ({ 
  posts, 
  currentUserId, 
  currentUsername,
  isBookmarked,
  onLike, 
  onBookmark,
  onDelete
}: ExploreViewProps) => {
  const [searchQuery, setSearchQuery] = useState('');

  const trendingTopics = [
    { tag: 'السعودية_2030', count: '12.5K' },
    { tag: 'برمجة', count: '8.2K' },
    { tag: 'تقنية', count: '6.7K' },
    { tag: 'ريادة_أعمال', count: '5.1K' },
  ];

  const filteredPosts = posts.filter(post =>
    post.content.includes(searchQuery) ||
    post.author_name.includes(searchQuery) ||
    post.username.includes(searchQuery)
  );

  return (
    <div dir="rtl" className="min-h-screen bg-white dark:bg-gray-900 pb-32">
      {/* Search Header */}
      <div className="sticky top-0 bg-white dark:bg-gray-900 p-4 z-10 border-b border-gray-100 dark:border-gray-800">
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن منشورات أو أشخاص..."
            className="w-full bg-gray-100 dark:bg-gray-800 rounded-2xl py-4 pr-12 pl-4 text-sm font-bold outline-none border-2 border-transparent focus:border-emerald-200 dark:focus:border-emerald-800 transition text-gray-900 dark:text-white"
          />
        </div>
      </div>

      {/* Trending Section */}
      {searchQuery === '' && (
        <div className="p-4 border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            <h3 className="font-black text-gray-900 dark:text-white">الترند</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {trendingTopics.map((topic, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSearchQuery(topic.tag)}
                className="px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-xl text-sm font-bold text-gray-700 dark:text-gray-200 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition"
              >
                <Hash className="w-3 h-3 inline-block mr-1" />
                {topic.tag}
                <span className="text-xs text-gray-400 mr-2">({topic.count})</span>
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {/* Search Results */}
      <div className="divide-y divide-gray-100 dark:divide-gray-800">
        {searchQuery !== '' && filteredPosts.length === 0 ? (
          <div className="p-20 text-center">
            <div className="text-6xl mb-4">🔍</div>
            <p className="text-gray-400 font-black">لا توجد نتائج</p>
            <p className="text-gray-400 text-sm mt-2">جرب البحث بكلمات مختلفة</p>
          </div>
        ) : (
          filteredPosts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              currentUserId={currentUserId}
              currentUsername={currentUsername}
              isBookmarked={isBookmarked(post.id)}
              onLike={onLike}
              onBookmark={onBookmark}
              onDelete={post.username === currentUsername ? onDelete : undefined}
            />
          ))
        )}
      </div>
    </div>
  );
};