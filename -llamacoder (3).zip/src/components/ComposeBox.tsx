import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Image, Smile, X } from 'lucide-react';
import { User } from '../types';
import { fileToBase64, validateImageFile } from '../utils/helpers';

interface ComposeBoxProps {
  user: User;
  onPost: (content: string, imageUrl?: string) => void;
}

export const ComposeBox = ({ user, onPost }: ComposeBoxProps) => {
  const [content, setContent] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validation = validateImageFile(file);
    if (!validation.valid) {
      setImageError(validation.error || 'خطأ في الصورة');
      return;
    }

    setImageError(null);
    const base64 = await fileToBase64(file);
    setSelectedImage(base64);
    setIsFocused(true);
  };

  const removeImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = () => {
    if (content.trim() || selectedImage) {
      onPost(content, selectedImage || undefined);
      setContent('');
      setSelectedImage(null);
      setIsFocused(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleCancel = () => {
    setContent('');
    setSelectedImage(null);
    setIsFocused(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const charCount = content.length;
  const maxChars = 280;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="px-5 py-5 border-b border-gray-100 dark:border-gray-800 bg-white dark:bg-gray-900"
      dir="rtl"
    >
      <div className="flex gap-4">
        <img
          src={user.avatar_url}
          alt={user.full_name}
          className="w-12 h-12 rounded-2xl object-cover border-2 border-white dark:border-gray-700 shadow-sm bg-gray-100"
        />
        <div className="flex-1">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onFocus={() => setIsFocused(true)}
            placeholder="اكتب همتك اليوم.. 🇸🇦"
            className="w-full bg-transparent border-none resize-none focus:ring-0 text-lg font-medium pt-2 text-gray-800 dark:text-gray-200 placeholder-gray-400 outline-none"
            rows={isFocused || selectedImage ? 3 : 2}
          />

          {/* Selected Image Preview */}
          <AnimatePresence>
            {selectedImage && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="relative mt-3 inline-block"
              >
                <img
                  src={selectedImage}
                  alt="Selected"
                  className="max-h-48 rounded-2xl object-cover"
                />
                <button
                  onClick={removeImage}
                  className="absolute top-2 left-2 w-8 h-8 bg-black/50 rounded-full flex items-center justify-center text-white hover:bg-black/70 transition"
                >
                  <X className="w-4 h-4" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Error Message */}
          {imageError && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 text-sm mt-2"
            >
              {imageError}
            </motion.p>
          )}

          <AnimatePresence>
            {isFocused && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="flex justify-between items-center mt-3"
              >
                <div className="flex gap-3 items-center">
                  {/* Image Button - Opens Gallery */}
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    onClick={() => fileInputRef.current?.click()}
                    className={`p-2 rounded-xl transition ${selectedImage ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20' : 'text-emerald-600 opacity-50 hover:opacity-100 hover:bg-gray-100 dark:hover:bg-gray-800'}`}
                  >
                    <Image className="w-5 h-5" />
                  </motion.button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="hidden"
                  />

                  <button className="text-emerald-600 opacity-50 hover:opacity-100 transition p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800">
                    <Smile className="w-5 h-5" />
                  </button>
                  <span className={`text-xs font-bold ${charCount > maxChars ? 'text-red-500' : 'text-gray-400'}`}>
                    {charCount}/{maxChars}
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleCancel}
                    className="px-4 py-2 rounded-xl text-gray-500 font-bold text-sm hover:bg-gray-100 dark:hover:bg-gray-800 transition"
                  >
                    إلغاء
                  </button>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={handleSubmit}
                    disabled={!content.trim() && !selectedImage}
                    className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-black shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition"
                  >
                    نشر
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {!isFocused && content === '' && !selectedImage && (
            <div className="flex justify-between items-center mt-3">
              <div className="flex gap-3">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="text-emerald-600 opacity-40 hover:opacity-100 transition p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <Image className="w-5 h-5" />
                </button>
                <button className="text-emerald-600 opacity-40 hover:opacity-100 transition p-2 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-800">
                  <Smile className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};