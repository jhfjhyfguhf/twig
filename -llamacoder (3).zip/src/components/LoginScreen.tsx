import { motion } from 'framer-motion';
import { Mountain } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
}

export const LoginScreen = ({ onLogin }: LoginScreenProps) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-50 bg-gradient-to-br from-emerald-600 to-emerald-800 flex flex-col items-center justify-center p-8 text-center"
      dir="rtl"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2, type: 'spring' }}
        className="mb-12 text-white"
      >
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="w-28 h-28 bg-white rounded-3xl flex items-center justify-center shadow-2xl mx-auto mb-6"
        >
          <Mountain className="w-14 h-14 text-emerald-700" />
        </motion.div>
        <h1 className="text-4xl font-black mb-3">منصة طويق</h1>
        <p className="text-white/80 font-medium text-lg">همة تعانق السماء 🇸🇦</p>
      </motion.div>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={onLogin}
        className="w-full max-w-xs bg-white text-gray-900 font-black py-4 px-6 rounded-2xl flex items-center justify-center gap-4 shadow-xl hover:bg-gray-50 transition"
      >
        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 via-red-500 to-yellow-500" />
        دخول سريع للمعاينة
      </motion.button>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-8 text-white/50 text-sm"
      >
        تجربة محلية - لا حاجة لاتصال بالإنترنت
      </motion.p>
    </motion.div>
  );
};