import { motion } from 'framer-motion';
import { Heart, MessageCircle, Share2, Bookmark, Trash2 } from 'lucide-react';
import { Post } from '../types';
import { formatDateShort } from '../utils/helpers';

interface PostCardProps {
  post: Post;
  currentUserId: string;
  currentUsername: string;
  isBookmarked: boolean;
  onLike: (id: string) => void;
  onBookmark: (id: string) => void;
  onDelete?: (id: string) => void;
  onShare?: (post: Post) => void;
}

export const PostCard = ({ 
  post, 
  currentUserId, 
  currentUsername, 
  isBookmarked, 
  onLike, 
  onBookmark,
  onDelete,
  onShare 
}: PostCardProps) => {
  const likedBy = post.likedBy || [];
  const isLiked = likedBy.includes(currentUserId);
  const isMyPost = post.username === currentUsername;

  const handleShare = () => {
    if (onShare) {
      onShare(post);
    } else {
      // Default share behavior - copy to clipboard
      navigator.clipboard.writeText(post.content);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-5 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 transition"
      dir="rtl"
    >
      <div className="flex gap-4 mb-3">
        <img
          src={post.author_avatar}
          alt={post.author_name}
          className="w-11 h-11 rounded-2xl object-cover shadow-sm bg-gray-100"
        />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h4 className="font-black text-sm text-gray-900 dark:text-white">{post.author_name}</h4>
            <div className="w-4 h-4 bg-emerald-600 rounded-full flex items-center justify-center">
              <span className="text-white text-[8px]">✓</span>
            </div>
            <span className="text-xs text-gray-400 font-bold mr-auto">
              {formatDateShort(post.created_at)}
            </span>
          </div>
          <p className="text-xs text-emerald-600 font-black opacity-60">@{post.username}</p>
        </div>
      </div>

      <p className="text-base leading-relaxed mb-4 font-medium text-gray-800 dark:text-gray-200 whitespace-pre-wrap">
        {post.content}
      </p>

      {post.image_url && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-4 rounded-2xl overflow-hidden"
        >
          <img
            src={post.image_url}
            alt="Post image"
            className="w-full max-h-80 object-cover"
          />
        </motion.div>
      )}

      <div className="flex gap-6">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => onLike(post.id)}
          className={`flex items-center gap-2 transition ${isLiked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}
        >
          <motion.div
            animate={isLiked ? { scale: [1, 1.3, 1] } : {}}
            transition={{ duration: 0.2 }}
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-red-500' : ''}`} />
          </motion.div>
          <span className="text-sm font-black">{post.likes || 0}</span>
        </motion.button>

        <button className="flex items-center gap-2 text-gray-400 hover:text-blue-500 transition">
          <MessageCircle className="w-5 h-5" />
          <span className="text-sm font-black">{post.comments || 0}</span>
        </button>

        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleShare}
          className="flex items-center gap-2 text-gray-400 hover:text-emerald-500 transition"
        >
          <Share2 className="w-5 h-5" />
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => onBookmark(post.id)}
          className={`flex items-center gap-2 transition mr-auto ${isBookmarked ? 'text-amber-500' : 'text-gray-400 hover:text-amber-500'}`}
        >
          <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-amber-500' : ''}`} />
        </motion.button>

        {isMyPost && onDelete && (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => onDelete(post.id)}
            className="flex items-center gap-2 text-gray-400 hover:text-red-500 transition"
          >
            <Trash2 className="w-5 h-5" />
          </motion.button>
        )}
      </div>
    </motion.div>
  );
};