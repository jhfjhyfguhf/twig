import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Camera } from 'lucide-react';
import { User } from '../types';
import { fileToBase64, validateImageFile } from '../utils/helpers';

interface EditProfileModalProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
  onSave: (user: User) => void;
}

export const EditProfileModal = ({ user, isOpen, onClose, onSave }: EditProfileModalProps) => {
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [location, setLocation] = useState('');
  const [birthday, setBirthday] = useState('');
  const [avatarUrl, setAvatarUrl] = useState('');
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user && isOpen) {
      setName(user.full_name);
      setBio(user.bio || '');
      setLocation(user.location || '');
      setBirthday(user.birthday || '');
      setAvatarUrl(user.avatar_url);
      setError('');
    }
  }, [user, isOpen]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, onClose]);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validation = validateImageFile(file);
    if (!validation.valid) {
      setError(validation.error || 'خطأ في الصورة');
      return;
    }

    setError('');
    const base64 = await fileToBase64(file);
    setAvatarUrl(base64);
  };

  const handleSave = () => {
    if (!name.trim()) {
      setError('الاسم إلزامي للمتابعة');
      return;
    }

    if (name.trim().length < 3) {
      setError('الاسم يجب أن يكون 3 أحرف على الأقل');
      return;
    }

    onSave({
      ...user,
      full_name: name.trim(),
      bio: bio.trim(),
      location: location.trim(),
      birthday: birthday,
      avatar_url: avatarUrl
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => {
            if (modalRef.current && !modalRef.current.contains(e.target as Node)) {
              onClose();
            }
          }}
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          dir="rtl"
        >
          <motion.div
            ref={modalRef}
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="bg-white dark:bg-gray-900 w-full max-w-md rounded-3xl p-6 shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black text-gray-900 dark:text-white">إعدادات الحساب</h3>
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 text-red-600 rounded-xl text-sm font-bold"
              >
                {error}
              </motion.div>
            )}

            <div className="space-y-5">
              {/* Avatar */}
              <div className="flex flex-col items-center gap-2">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="relative group"
                >
                  <img
                    src={avatarUrl}
                    alt="Avatar"
                    className="w-24 h-24 rounded-3xl object-cover border-4 border-emerald-600 shadow-xl"
                  />
                  <div className="absolute inset-0 bg-black/40 rounded-3xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all">
                    <Camera className="w-6 h-6 text-white" />
                  </div>
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <p className="text-xs font-black text-gray-400 uppercase tracking-widest">تحديث الصورة</p>
              </div>

              {/* Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-black text-gray-400 uppercase tracking-tighter">الاسم الكامل (إلزامي)</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    setError('');
                  }}
                  placeholder="أدخل اسمك"
                  className="w-full bg-gray-50 dark:bg-gray-800 border-2 border-transparent rounded-2xl px-4 py-3 font-semibold outline-none focus:border-emerald-600 focus:bg-white dark:focus:bg-gray-800 transition text-gray-900 dark:text-white"
                />
              </div>

              {/* Bio */}
              <div className="space-y-1.5">
                <label className="text-xs font-black text-gray-400 uppercase tracking-tighter">النبذة التعريفية (اختياري)</label>
                <textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="من أنت؟"
                  rows={3}
                  className="w-full bg-gray-50 dark:bg-gray-800 border-2 border-transparent rounded-2xl px-4 py-3 font-semibold outline-none focus:border-emerald-600 focus:bg-white dark:focus:bg-gray-800 transition resize-none text-gray-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                {/* Location */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-tighter">المنطقة</label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="مثلاً: الرياض"
                    className="w-full bg-gray-50 dark:bg-gray-800 border-2 border-transparent rounded-2xl px-4 py-3 font-semibold outline-none focus:border-emerald-600 focus:bg-white dark:focus:bg-gray-800 transition text-gray-900 dark:text-white"
                  />
                </div>

                {/* Birthday */}
                <div className="space-y-1.5">
                  <label className="text-xs font-black text-gray-400 uppercase tracking-tighter">ميلادك</label>
                  <input
                    type="date"
                    value={birthday}
                    onChange={(e) => setBirthday(e.target.value)}
                    className="w-full bg-gray-50 dark:bg-gray-800 border-2 border-transparent rounded-2xl px-4 py-3 font-semibold outline-none focus:border-emerald-600 focus:bg-white dark:focus:bg-gray-800 transition text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={onClose}
                  className="flex-1 bg-gray-100 dark:bg-gray-800 py-4 rounded-2xl font-black text-sm text-gray-700 dark:text-gray-200"
                >
                  إلغاء
                </button>
                <motion.button
                  whileTap={{ scale: 0.98 }}
                  onClick={handleSave}
                  className="flex-[2] bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-lg text-sm"
                >
                  حفظ التغييرات
                </motion.button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};