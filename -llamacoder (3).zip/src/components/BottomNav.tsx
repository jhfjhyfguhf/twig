import { motion } from 'framer-motion';
import { Home, Search, Bell, User } from 'lucide-react';
import { TabType } from '../types';

interface BottomNavProps {
  currentTab: TabType;
  unreadNotifications: number;
  onTabChange: (tab: TabType) => void;
}

export const BottomNav = ({ currentTab, unreadNotifications, onTabChange }: BottomNavProps) => {
  const tabs = [
    { id: 'home' as TabType, icon: Home, label: 'الرئيسية' },
    { id: 'explore' as TabType, icon: Search, label: 'استكشاف' },
    { id: 'notifications' as TabType, icon: Bell, label: 'الإشعارات' },
    { id: 'profile' as TabType, icon: User, label: 'الملف' },
  ];

  return (
    <nav
      className="shrink-0 bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-700 flex justify-around items-center h-20 px-4"
      dir="rtl"
    >
      {tabs.map((tab) => {
        const isActive = currentTab === tab.id;
        const Icon = tab.icon;

        return (
          <motion.button
            key={tab.id}
            whileTap={{ scale: 0.9 }}
            onClick={() => onTabChange(tab.id)}
            className="flex flex-col items-center gap-1 flex-1 relative"
          >
            <div className="relative">
              <Icon
                className={`w-6 h-6 transition-colors ${isActive ? 'text-emerald-600' : 'text-gray-400'}`}
              />
              {tab.id === 'notifications' && unreadNotifications > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center font-bold">
                  {unreadNotifications > 9 ? '9' : unreadNotifications}
                </span>
              )}
            </div>
            <span
              className={`text-xs font-black uppercase tracking-wider ${isActive ? 'text-emerald-600' : 'text-gray-400'}`}
            >
              {tab.label}
            </span>
            {isActive && (
              <motion.div
                layoutId="navIndicator"
                className="absolute -bottom-1 w-8 h-1 bg-emerald-600 rounded-full"
              />
            )}
          </motion.button>
        );
      })}
    </nav>
  );
};