import { motion, AnimatePresence } from 'framer-motion';
import { Mountain, Moon, Sun, MoreVertical, UserCog, LogOut, Bell } from 'lucide-react';
import { User } from '../types';
import { useState, useRef, useEffect } from 'react';

interface HeaderProps {
  user: User;
  isDark: boolean;
  unreadNotifications: number;
  onToggleTheme: () => void;
  onOpenSettings: () => void;
  onLogout: () => void;
  onNotificationsClick: () => void;
}

export const Header = ({
  user,
  isDark,
  unreadNotifications,
  onToggleTheme,
  onOpenSettings,
  onLogout,
  onNotificationsClick
}: HeaderProps) => {
  const [showMenu, setShowMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header
      className="shrink-0 px-4 py-3 flex justify-between items-center z-40 border-b border-gray-200/50 bg-white dark:bg-gray-900 dark:border-gray-700"
      dir="rtl"
    >
      <div className="flex items-center gap-3">
        <motion.div
          whileHover={{ rotate: 15, scale: 1.1 }}
          className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg"
        >
          <Mountain className="w-5 h-5 text-white" />
        </motion.div>
        <h1 className="text-xl font-black tracking-tighter text-gray-900 dark:text-white">طويق</h1>
      </div>

      <div className="flex items-center gap-2 relative" ref={menuRef}>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onToggleTheme}
          className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-300 transition"
        >
          {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onNotificationsClick}
          className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-300 transition relative"
        >
          <Bell className="w-5 h-5" />
          {unreadNotifications > 0 && (
            <motion.span
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute -top-1 -left-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center font-bold"
            >
              {unreadNotifications > 9 ? '9+' : unreadNotifications}
            </motion.span>
          )}
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setShowMenu(!showMenu)}
          className="w-10 h-10 rounded-xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-600 dark:text-gray-300 transition"
        >
          <MoreVertical className="w-5 h-5" />
        </motion.button>

        <AnimatePresence>
          {showMenu && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: -10 }}
              className="absolute top-14 left-0 w-56 bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-700 overflow-hidden z-50"
            >
              <button
                onClick={() => {
                  onOpenSettings();
                  setShowMenu(false);
                }}
                className="w-full text-right px-5 py-4 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between font-bold text-sm text-gray-700 dark:text-gray-200"
              >
                <span>إعدادات الملف</span>
                <UserCog className="w-4 h-4 text-gray-400" />
              </button>
              <button
                onClick={() => {
                  onLogout();
                  setShowMenu(false);
                }}
                className="w-full text-right px-5 py-4 hover:bg-red-50 dark:hover:bg-red-900/20 text-red-500 flex items-center justify-between font-bold text-sm"
              >
                <span>تسجيل الخروج</span>
                <LogOut className="w-4 h-4 text-red-400" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
};