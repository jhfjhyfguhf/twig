import { motion } from 'framer-motion';
import { MapPin, Cake, Calendar, Settings, Heart, Image, Star } from 'lucide-react';
import { User, Post, ProfileTabType } from '../types';
import { PostCard } from './PostCard';
import { useState } from 'react';
import { formatJoinDate } from '../utils/helpers';

interface ProfileViewProps {
  user: User;
  posts: Post[];
  currentUserId: string;
  isBookmarked: (id: string) => boolean;
  onLike: (id: string) => void;
  onBookmark: (id: string) => void;
  onDelete: (id: string) => void;
  onOpenSettings: () => void;
}

export const ProfileView = ({ 
  user, 
  posts, 
  currentUserId, 
  isBookmarked,
  onLike, 
  onBookmark,
  onDelete,
  onOpenSettings 
}: ProfileViewProps) => {
  const [activeTab, setActiveTab] = useState<ProfileTabType>('my-tweets');

  const userPosts = posts.filter(p => p.username === user.username);
  const likedPosts = posts.filter(p => p.likedBy.includes(currentUserId));
  const mediaPosts = posts.filter(p => p.username === user.username && p.image_url);

  const tabs: { id: ProfileTabType; label: string; icon: React.ReactNode; count: number }[] = [
    { id: 'my-tweets', label: 'المنشورات', icon: <Star className="w-4 h-4" />, count: userPosts.length },
    { id: 'my-media', label: 'الوسائط', icon: <Image className="w-4 h-4" />, count: mediaPosts.length },
    { id: 'my-likes', label: 'الإعجابات', icon: <Heart className="w-4 h-4" />, count: likedPosts.length },
  ];

  const stats = [
    { value: '1.2K', label: 'متابِع' },
    { value: '850', label: 'يتابع' },
    { value: userPosts.length.toString(), label: 'منشور' },
  ];

  const getTabContent = () => {
    switch (activeTab) {
      case 'my-tweets':
        return userPosts;
      case 'my-media':
        return mediaPosts;
      case 'my-likes':
        return likedPosts;
      default:
        return [];
    }
  };

  const displayPosts = getTabContent();

  return (
    <div dir="rtl" className="pb-32">
      {/* Banner */}
      <div className="h-44 bg-gradient-to-br from-emerald-600 to-emerald-800 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 opacity-20"
        >
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.5 + 0.2
              }}
            />
          ))}
        </motion.div>
      </div>

      {/* Profile Info */}
      <div className="px-6 -mt-14 relative z-10 bg-white dark:bg-gray-900">
        <div className="flex justify-between items-start">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="relative inline-block"
          >
            <img
              src={user.avatar_url}
              alt={user.full_name}
              className="w-28 h-28 rounded-3xl bg-white dark:bg-gray-800 border-4 border-white dark:border-gray-900 shadow-2xl object-cover"
            />
            <div className="absolute bottom-1 left-1 w-7 h-7 bg-amber-500 rounded-full border-4 border-white dark:border-gray-900 flex items-center justify-center">
              <span className="text-white text-xs">✓</span>
            </div>
          </motion.div>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={onOpenSettings}
            className="mt-16 px-5 py-2.5 border-2 border-emerald-600 text-emerald-600 rounded-xl font-black text-sm hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition flex items-center gap-2"
          >
            <Settings className="w-4 h-4" />
            تعديل
          </motion.button>
        </div>

        <div className="mt-4">
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black tracking-tight text-gray-900 dark:text-white">{user.full_name}</h2>
            <div className="w-5 h-5 bg-emerald-600 rounded-full flex items-center justify-center">
              <span className="text-white text-[10px]">✓</span>
            </div>
          </div>
          <p className="text-emerald-600 font-black text-sm opacity-60">@{user.username}</p>
          <p className="mt-4 text-base font-medium text-gray-600 dark:text-gray-300 leading-relaxed">
            {user.bio || "لا توجد نبذة تعريفية.."}
          </p>

          <div className="flex flex-wrap items-center gap-x-5 gap-y-2 mt-4 text-xs text-gray-500 font-bold">
            {user.location && (
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                {user.location}
              </span>
            )}
            {user.birthday && (
              <span className="flex items-center gap-1">
                <Cake className="w-3.5 h-3.5" />
                {user.birthday}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              انضم في {formatJoinDate(user.joinDate)}
            </span>
          </div>

          {/* Stats */}
          <div className="flex gap-10 mt-8 py-5 border-y border-gray-100 dark:border-gray-800">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="font-black text-lg text-gray-900 dark:text-white">{stat.value}</div>
                <div className="text-[9px] text-gray-400 font-black uppercase tracking-widest">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 dark:border-gray-800 sticky top-0 bg-white dark:bg-gray-900 z-20">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-4 text-xs font-black transition-all flex items-center justify-center gap-2 ${
              activeTab === tab.id
                ? 'text-emerald-600 border-b-2 border-emerald-600'
                : 'text-gray-400 opacity-50 hover:opacity-100'
            }`}
          >
            {tab.icon}
            {tab.label}
            <span className="text-[10px] bg-gray-100 dark:bg-gray-800 px-2 py-0.5 rounded-full">
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Posts */}
      <div className="divide-y divide-gray-100 dark:divide-gray-800">
        {displayPosts.length === 0 ? (
          <div className="p-20 text-center">
            <div className="text-6xl mb-4">
              {activeTab === 'my-tweets' ? '📝' : activeTab === 'my-media' ? '🖼️' : '❤️'}
            </div>
            <p className="text-gray-400 font-black">
              {activeTab === 'my-tweets' && 'لا توجد منشورات'}
              {activeTab === 'my-media' && 'لا توجد وسائط'}
              {activeTab === 'my-likes' && 'لم تعجب بأي منشور بعد'}
            </p>
          </div>
        ) : (
          displayPosts.map(post => (
            <PostCard
              key={post.id}
              post={post}
              currentUserId={currentUserId}
              currentUsername={user.username}
              isBookmarked={isBookmarked(post.id)}
              onLike={onLike}
              onBookmark={onBookmark}
              onDelete={post.username === user.username ? onDelete : undefined}
            />
          ))
        )}
      </div>
    </div>
  );
};