import { motion, AnimatePresence } from 'framer-motion';
import { Check } from 'lucide-react';

interface ToastProps {
  message: string;
  isVisible: boolean;
}

export const Toast = ({ message, isVisible }: ToastProps) => {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50, x: '-50%' }}
          animate={{ opacity: 1, y: 0, x: '-50%' }}
          exit={{ opacity: 0, y: 50, x: '-50%' }}
          className="fixed bottom-24 left-1/2 bg-gray-900 text-white px-6 py-3 rounded-2xl text-sm font-black shadow-2xl z-[200] flex items-center gap-3"
          dir="rtl"
        >
          <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center">
            <Check className="w-3 h-3 text-white" />
          </div>
          {message}
        </motion.div>
      )}
    </AnimatePresence>
  );
};