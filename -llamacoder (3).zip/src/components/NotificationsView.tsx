import { motion } from 'framer-motion';
import { Heart, MessageCircle, UserPlus } from 'lucide-react';
import { Notification } from '../types';
import { formatDateShort } from '../utils/helpers';

interface NotificationsViewProps {
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllAsRead: () => void;
}

export const NotificationsView = ({ notifications, onMarkAsRead, onMarkAllAsRead }: NotificationsViewProps) => {
  const unreadCount = notifications.filter(n => !n.read).length;

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-5 h-5 text-red-500" />;
      case 'comment':
        return <MessageCircle className="w-5 h-5 text-blue-500" />;
      case 'follow':
        return <UserPlus className="w-5 h-5 text-emerald-500" />;
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-white dark:bg-gray-900 pb-32">
      {/* Header */}
      <div className="sticky top-0 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 p-4 z-10">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-black text-gray-900 dark:text-white">الإشعارات</h2>
          {unreadCount > 0 && (
            <button
              onClick={onMarkAllAsRead}
              className="text-sm text-emerald-600 font-bold hover:underline"
            >
              تحديد الكل كمقروء
            </button>
          )}
        </div>
        {unreadCount > 0 && (
          <p className="text-sm text-gray-500 mt-1">{unreadCount} إشعار جديد</p>
        )}
      </div>

      {/* Notifications List */}
      <div className="divide-y divide-gray-100 dark:divide-gray-800">
        {notifications.length === 0 ? (
          <div className="p-20 text-center">
            <div className="text-6xl mb-4">🔔</div>
            <p className="text-gray-400 font-black">لا توجد إشعارات</p>
          </div>
        ) : (
          notifications.map((notification) => (
            <motion.div
              key={notification.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => !notification.read && onMarkAsRead(notification.id)}
              className={`p-4 flex gap-4 cursor-pointer transition ${
                !notification.read 
                  ? 'bg-emerald-50 dark:bg-emerald-900/10' 
                  : 'bg-white dark:bg-gray-900'
              }`}
            >
              <div className="relative">
                <img
                  src={notification.fromAvatar}
                  alt={notification.fromUser}
                  className="w-12 h-12 rounded-2xl object-cover bg-gray-100"
                />
                <div className="absolute -bottom-1 -left-1 w-6 h-6 bg-white dark:bg-gray-900 rounded-full flex items-center justify-center shadow-sm">
                  {getIcon(notification.type)}
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800 dark:text-gray-200">
                  <span className="font-black">{notification.fromUser}</span>
                  {' '}{notification.message}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {formatDateShort(notification.createdAt)}
                </p>
              </div>
              {!notification.read && (
                <div className="w-2 h-2 bg-emerald-500 rounded-full self-center" />
              )}
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};